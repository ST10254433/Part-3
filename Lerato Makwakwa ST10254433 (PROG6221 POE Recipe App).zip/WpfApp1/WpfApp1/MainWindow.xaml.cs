﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using RecipeAppWPF.Models;

namespace RecipeAppWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private List<Recipe> recipes = new List<Recipe>();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void EnterRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            string userName = UserNameTextBox.Text;
            string userSurname = UserSurnameTextBox.Text;

            if (string.IsNullOrWhiteSpace(userName) || string.IsNullOrWhiteSpace(userSurname))
            {
                MessageBox.Show("Please enter user details.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            User user = new User { Name = userName, Surname = userSurname };

            RecipeWindow recipeWindow = new RecipeWindow(recipes);
            recipeWindow.ShowDialog();
            UpdateRecipeList();
        }

        private void FilterRecipesButton_Click(object sender, RoutedEventArgs e)
        {
            string ingredient = FilterIngredientTextBox.Text.ToLower();
            string foodGroup = FilterFoodGroupTextBox.Text.ToLower();
            bool isCaloriesValid = int.TryParse(FilterCaloriesTextBox.Text, out int maxCalories);

            var filteredRecipes = recipes.Where(r =>
                (string.IsNullOrEmpty(ingredient) || r.Ingredients.Any(i => i.Name.ToLower().Contains(ingredient))) &&
                (string.IsNullOrEmpty(foodGroup) || r.Ingredients.Any(i => i.FoodGroup.ToLower().Contains(foodGroup))) &&
                (!isCaloriesValid || r.CalculateTotalCalories() <= maxCalories)).ToList();

            RecipeListBox.ItemsSource = filteredRecipes.Select(r => r.Name);
        }

        private void DisplayRecipeDetailsButton_Click(object sender, RoutedEventArgs e)
        {
            if (RecipeListBox.SelectedItem == null)
            {
                MessageBox.Show("Please select a recipe.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            string chosenRecipeName = RecipeListBox.SelectedItem.ToString();
            Recipe chosenRecipe = recipes.Find(r => r.Name.Equals(chosenRecipeName, StringComparison.OrdinalIgnoreCase));

            if (chosenRecipe != null)
            {
                RecipeDetailsWindow recipeDetailsWindow = new RecipeDetailsWindow(chosenRecipe);
                recipeDetailsWindow.ShowDialog();
            }
            else
            {
                MessageBox.Show("Recipe not found.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void DisplayPieChartButton_Click(object sender, RoutedEventArgs e)
        {
            var selectedRecipes = RecipeListBox.SelectedItems.Cast<string>()
                .Select(name => recipes.Find(r => r.Name.Equals(name, StringComparison.OrdinalIgnoreCase)))
                .ToList();

            if (selectedRecipes.Any())
            {
                MenuPieChartWindow menuPieChartWindow = new MenuPieChartWindow(selectedRecipes);
                menuPieChartWindow.ShowDialog();
            }
            else
            {
                MessageBox.Show("Please select at least one recipe.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void UpdateRecipeList()
        {
            recipes.Sort((x, y) => x.Name.CompareTo(y.Name));
            RecipeListBox.ItemsSource = recipes.Select(r => r.Name);
        }
    }
}