﻿using LiveCharts.Wpf;
using LiveCharts;
using RecipeAppWPF.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace RecipeAppWPF
{
    /// <summary>
    /// Interaction logic for MenuPieChartWindow.xaml
    /// </summary>
    public partial class MenuPieChartWindow : Window
    {
        public MenuPieChartWindow(List<Recipe> selectedRecipes)
        {
            InitializeComponent();
            DisplayPieChart(selectedRecipes);
        }

        private void DisplayPieChart(List<Recipe> recipes)
        {
            var foodGroupTotals = new Dictionary<string, double>();

            foreach (var recipe in recipes)
            {
                foreach (var ingredient in recipe.Ingredients)
                {
                    if (foodGroupTotals.ContainsKey(ingredient.FoodGroup))
                    {
                        foodGroupTotals[ingredient.FoodGroup] += ingredient.Calories * ingredient.Quantity;
                    }
                    else
                    {
                        foodGroupTotals[ingredient.FoodGroup] = ingredient.Calories * ingredient.Quantity;
                    }
                }
            }

            var pieSeries = new SeriesCollection();

            foreach (var foodGroup in foodGroupTotals)
            {
                pieSeries.Add(new PieSeries
                {
                    Title = foodGroup.Key,
                    Values = new ChartValues<double> { foodGroup.Value },
                    DataLabels = true
                });
            }

            PieChart.Series = pieSeries;
        }

        private void PieChart_Loaded(object sender, RoutedEventArgs e)
        {

        }
    }
}

