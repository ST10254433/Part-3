﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using RecipeAppWPF.Models;

namespace RecipeAppWPF
{
    /// <summary>
    /// Interaction logic for Ingredient.xaml
    /// </summary>
    public partial class IngredientWindow : Window
    {
        public Ingredient NewIngredient { get; private set; }

        public IngredientWindow()
        {
            InitializeComponent();
        }

        private void SaveIngredientButton_Click(object sender, RoutedEventArgs e)
        {
            string name = IngredientNameTextBox.Text;
            if (!double.TryParse(IngredientQuantityTextBox.Text, out double quantity))
            {
                MessageBox.Show("Please enter a valid quantity.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            string unit = IngredientUnitTextBox.Text;
            if (!int.TryParse(IngredientCaloriesTextBox.Text, out int calories))
            {
                MessageBox.Show("Please enter a valid number of calories.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }
            string foodGroup = IngredientFoodGroupTextBox.Text;

            NewIngredient = new Ingredient(name, quantity, unit, calories, foodGroup);
            DialogResult = true;
            Close();
        }
    }
}
