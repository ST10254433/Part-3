﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using RecipeAppWPF.Models;

namespace RecipeAppWPF
{
    /// <summary>
    /// Interaction logic for RecipeWindow.xaml
    /// </summary>
    public partial class RecipeWindow : Window
    {
        private List<Recipe> recipes;
        private Recipe currentRecipe;

        public RecipeWindow(List<Recipe> recipes)
        {
            InitializeComponent();
            this.recipes = recipes;
            currentRecipe = new Recipe(string.Empty);
        }

        private void AddIngredientButton_Click(object sender, RoutedEventArgs e)
        {
            IngredientWindow ingredientWindow = new IngredientWindow();
            if (ingredientWindow.ShowDialog() == true)
            {
                Ingredient newIngredient = ingredientWindow.NewIngredient;
                currentRecipe.AddIngredient(newIngredient);
                IngredientsListBox.Items.Add($"{newIngredient.Name} - {newIngredient.Quantity} {newIngredient.Unit} - {newIngredient.Calories} calories - {newIngredient.FoodGroup}");
            }
        }

        private void AddStepButton_Click(object sender, RoutedEventArgs e)
        {
            string stepDescription = Microsoft.VisualBasic.Interaction.InputBox("Enter step description:", "Add Step", string.Empty);
            if (!string.IsNullOrWhiteSpace(stepDescription))
            {
                currentRecipe.AddStep(stepDescription);
                StepsListBox.Items.Add(stepDescription);
            }
        }

        private void SaveRecipeButton_Click(object sender, RoutedEventArgs e)
        {
            string recipeName = RecipeNameTextBox.Text;
            if (string.IsNullOrWhiteSpace(recipeName))
            {
                MessageBox.Show("Please enter a recipe name.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            currentRecipe.Name = recipeName;
            recipes.Add(currentRecipe);
            Close();
        }
    }
}
